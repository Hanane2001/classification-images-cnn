
# from pathlib import Path
# import random

# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns

# from PIL import Image, UnidentifiedImageError
# from sklearn.model_selection import train_test_split

# DATASET_DIR = Path("data/raw")

# CLASSES_ATTENDUES = [
#     "buildings",
#     "forest",
#     "glacier",
#     "mountain",
#     "sea",
#     "street"
# ]

# FORMATS_VALIDES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# TAILLE_IMAGE = (150, 150)

# RANDOM_STATE = 42

# def trouver_dossier_classes():
#     dossier_train = DATASET_DIR / "seg_train"
#     if dossier_train.exists():
#         return dossier_train

#     return DATASET_DIR

# def identifier_classes(dossier_classes):
#     classes = sorted([
#         dossier.name
#         for dossier in dossier_classes.iterdir()
#         if dossier.is_dir()
#         and dossier.name in CLASSES_ATTENDUES
#     ])

#     print("Classes trouvées:")
#     for classe in classes:
#         print("-", classe)
#     classes_manquantes = set(CLASSES_ATTENDUES) - set(classes)
#     if classes_manquantes:
#         print("Attention, classes manquantes:", classes_manquantes)

#     return classes

# def creer_dataframe(dossier_classes, classes):
#     donnees = []

#     for classe in classes:
#         dossier_classe = dossier_classes / classe

#         for chemin in dossier_classe.rglob("*"):
#             if chemin.is_file() and chemin.suffix.lower() in FORMATS_VALIDES:
#                 donnees.append({"chemin": str(chemin), "label": classe})

#     df = pd.DataFrame(donnees)
#     print("\nNombre total d'images:", len(df))
#     return df

# def compter_images(df):
#     distribution = (df["label"].value_counts().reindex(CLASSES_ATTENDUES, fill_value=0))
#     print("\nDistribution des images:")
#     print(distribution)
#     print("\nNombre total:", distribution.sum())
#     return distribution

# def afficher_distribution(distribution):
#     plt.figure(figsize=(10, 5))
#     sns.barplot(x=distribution.index, y=distribution.values)
#     plt.title("Nombre d'images par classe")
#     plt.xlabel("Classes")
#     plt.ylabel("Nombre d'images")
#     plt.xticks(rotation=30)
#     plt.tight_layout()
#     plt.show()

# def afficher_exemples(df, nombre=3):
#     classes_presentes = [
#         classe for classe in CLASSES_ATTENDUES
#         if classe in df["label"].values
#     ]

#     fig, axes = plt.subplots(
#         len(classes_presentes),
#         nombre,
#         figsize=(4 * nombre, 3 * len(classes_presentes)),
#         squeeze=False
#     )

#     for ligne, classe in enumerate(classes_presentes):
#         exemples = df[df["label"] == classe]

#         exemples = exemples.sample(
#             n=min(nombre, len(exemples)),
#             random_state=RANDOM_STATE
#         )

#         for colonne, (_, exemple) in enumerate(exemples.iterrows()):
#             chemin = exemple["chemin"]

#             with Image.open(chemin) as image:
#                 axes[ligne, colonne].imshow(image.convert("RGB"))

#             axes[ligne, colonne].set_title(classe)
#             axes[ligne, colonne].axis("off")

#         for colonne in range(len(exemples), nombre):
#             axes[ligne, colonne].axis("off")

#     plt.suptitle("Exemples d'images par classe")
#     plt.tight_layout()
#     plt.show()


# def verifier_dimensions_formats(df):
#     dimensions = []
#     formats = []
#     modes = []
#     images_invalides = []

#     for chemin in df["chemin"]:
#         try:
#             with Image.open(chemin) as image:
#                 image.verify()
#             with Image.open(chemin) as image:
#                 dimensions.append(image.size)
#                 formats.append(image.format)
#                 modes.append(image.mode)

#         except (OSError, UnidentifiedImageError, ValueError):
#             images_invalides.append(chemin)

#     print("\nNombre d'images vérifiées:", len(df))
#     print("Images invalides:", len(images_invalides))

#     if dimensions:
#         df_dimensions = pd.Series(dimensions)

#         print("\nDimensions les plus fréquentes:")
#         print(df_dimensions.value_counts().head(10))

#     print("\nFormats rencontrés:")
#     print(pd.Series(formats).value_counts())

#     print("\nModes couleur rencontrés:")
#     print(pd.Series(modes).value_counts())

#     if images_invalides:
#         print("\nExemples d'images invalides:")
#         for chemin in images_invalides[:10]:
#             print(chemin)

#     return images_invalides

# def verifier_chemins_dupliques(df):
#     nombre_doublons = df["chemin"].duplicated().sum()
#     print("\nChemins dupliqués:", nombre_doublons)
#     return nombre_doublons

# def separer_donnees(df, dossier_test=None):
#     if df.empty:
#         raise ValueError("Aucune image valide à séparer")

#     if df["label"].nunique() < 2:
#         raise ValueError("Il faut au moins deux classes présentes")
#     if dossier_test is not None and dossier_test.exists():
#         df_train, df_val = train_test_split(df, test_size=0.15, random_state=RANDOM_STATE, stratify=df["label"])
#         classes_test = [
#             classe for classe in CLASSES_ATTENDUES
#             if (dossier_test / classe).is_dir()
#         ]
#         df_test = creer_dataframe(dossier_test, classes_test)

#     else:
#         df_train, df_temp = train_test_split(df, test_size=0.30, random_state=RANDOM_STATE, stratify=df["label"])
#         df_val, df_test = train_test_split(df_temp, test_size=0.50, random_state=RANDOM_STATE, stratify=df_temp["label"])
#     print("\nRépartition des données:")
#     print("Train:", len(df_train))
#     print("Validation:", len(df_val))
#     print("Test:", len(df_test))

#     return df_train, df_val, df_test

# def sauvegarder_separations(df_train, df_val, df_test):
#     dossier_sortie = Path("data/processed")
#     dossier_sortie.mkdir(parents=True, exist_ok=True)
#     df_train.to_csv(dossier_sortie / "train.csv", index=False)
#     df_val.to_csv(dossier_sortie / "validation.csv", index=False)
#     df_test.to_csv(dossier_sortie / "test.csv", index=False)
#     print("\nLes trois fichiers CSV ont été sauvegardés")

# def main():
#     dossier_classes = trouver_dossier_classes()
#     print("Dossier utilisé:", dossier_classes)
#     classes = identifier_classes(dossier_classes)

#     if not classes:
#         raise ValueError("Aucune classe trouvée. Vérifiez DATASET_DIR")
#     df = creer_dataframe(dossier_classes, classes)
#     if df.empty:
#         raise ValueError("Aucune image trouvée dans le dataset")

#     compter_images(df)
#     distribution = compter_images(df)
#     afficher_distribution(distribution)

#     afficher_exemples(df, nombre=3)
#     images_invalides = verifier_dimensions_formats(df)
#     verifier_chemins_dupliques(df)

#     if images_invalides:
#         df = df[~df["chemin"].isin(images_invalides)].copy()
#     dossier_test = DATASET_DIR / "seg_test"

#     if not dossier_test.exists():
#         dossier_test = None

#     df_train, df_val, df_test = separer_donnees(df, dossier_test=dossier_test)
#     sauvegarder_separations(df_train, df_val, df_test)
#     print("\nExploration terminée")
